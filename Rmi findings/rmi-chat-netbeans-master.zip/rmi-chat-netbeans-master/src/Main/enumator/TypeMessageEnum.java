package Main.enumator;

public enum TypeMessageEnum {
    LOGIN, LOGOUT, PUBLIC, PRIVATE
}
